import { InterviewApp } from '@/components/InterviewApp';

const Index = () => {
  return <InterviewApp />;
};

export default Index;
